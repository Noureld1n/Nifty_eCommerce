import { useEffect, useState } from 'react'
import { Link, Outlet } from 'react-router-dom'
import Logo from '../components/Logo'
import './AuthLayout.css'

// The runner sprints in once per page load, then settles into a steady jog.
let hasArrived = false

/**
 * The page is split down the middle like the apple: green on the left, blue on the right.
 * The runner stands on top of the card, so the card's top edge is the ground.
 */
export default function AuthLayout() {
  const [arriving, setArriving] = useState(!hasArrived)

  useEffect(() => {
    if (!arriving) return undefined
    hasArrived = true
    const t = setTimeout(() => setArriving(false), 1100)
    return () => clearTimeout(t)
  }, [arriving])

  return (
    <div className="auth">
      <div className="auth__split" aria-hidden="true"><i /><i /></div>

      <header className="auth__top">
        <Link to="/" className="auth__brand" aria-label="Newtin home">
          <Logo size={40} wordmark speed="paused" />
        </Link>
      </header>

      <main className="auth__stage">
        <div className={`auth__runner ${arriving ? 'is-arriving' : ''}`}>
          <Logo size={150} speed={arriving ? 'fast' : 'normal'} />
        </div>
        <Outlet />
      </main>
    </div>
  )
}
