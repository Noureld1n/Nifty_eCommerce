import { useState } from 'react'
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '../auth/useAuth'
import Logo from '../components/Logo'
import { Avatar, Button } from '../components/ui'
import { roleLabel } from '../lib/format'
import './AppShell.css'

/** Shared frame for the customer and admin areas. `links` decides the tabs. */
export default function AppShell({ links }) {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [leaving, setLeaving] = useState(false)

  async function signOut() {
    setLeaving(true)
    await logout()
    navigate('/login', { replace: true })
  }

  return (
    <div className="shell">
      <header className="shell__bar">
        <div className="shell__inner">
          <Link to="/" className="shell__brand" aria-label="Newtin home">
            <Logo size={38} wordmark speed="paused" />
          </Link>
          <div className="shell__user">
            <Avatar user={user} size="2.25rem" />
            <div className="shell__who">
              <strong>{user.firstName} {user.lastName}</strong>
              <span>{roleLabel(user.role)}</span>
            </div>
            <Button variant="ghost" small loading={leaving} onClick={signOut}>Log out</Button>
          </div>
        </div>
        <nav className="shell__tabs" aria-label="Sections">
          {links.map((l) => (
            <NavLink key={l.to} to={l.to}>{l.label}</NavLink>
          ))}
        </nav>
      </header>
      <main className="shell__main">
        <Outlet />
      </main>
    </div>
  )
}
