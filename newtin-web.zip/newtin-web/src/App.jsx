import { Navigate, Route, Routes } from 'react-router-dom'
import { GuestOnly, RequireRole } from './auth/RouteGuards'
import { homeFor, useAuth } from './auth/useAuth'
import Splash from './components/Splash'
import AuthLayout from './layouts/AuthLayout'
import AppShell from './layouts/AppShell'
import LoginPage from './pages/auth/LoginPage'
import RegisterPage from './pages/auth/RegisterPage'
import CheckEmailPage from './pages/auth/CheckEmailPage'
import VerifyEmailPage from './pages/auth/VerifyEmailPage'
import ForgotPasswordPage from './pages/auth/ForgotPasswordPage'
import ResetPasswordPage from './pages/auth/ResetPasswordPage'
import NotFoundPage from './pages/auth/NotFoundPage'
import ProfilePage from './pages/user/ProfilePage'
import SecurityPage from './pages/user/SecurityPage'
import FeedbackPage from './pages/user/FeedbackPage'
import UsersPage from './pages/admin/UsersPage'
import AdminFeedbackPage from './pages/admin/AdminFeedbackPage'
import AuditLogPage from './pages/admin/AuditLogPage'

const CUSTOMER_LINKS = [
  { to: '/account/profile', label: 'Profile' },
  { to: '/account/security', label: 'Security' },
  { to: '/account/feedback', label: 'Feedback' },
]
const ADMIN_LINKS = [
  { to: '/admin/users', label: 'Users' },
  { to: '/admin/feedback', label: 'Feedback' },
  { to: '/admin/audit-log', label: 'Audit log' },
]

function RootRedirect() {
  const { user, booting } = useAuth()
  if (booting) return <Splash />
  return <Navigate to={user ? homeFor(user) : '/login'} replace />
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<RootRedirect />} />

      {/* Logged-out only */}
      <Route element={<GuestOnly />}>
        <Route element={<AuthLayout />}>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
        </Route>
      </Route>

      {/* Reachable from email links, whether or not someone is logged in */}
      <Route element={<AuthLayout />}>
        <Route path="/check-email" element={<CheckEmailPage />} />
        <Route path="/verify-email" element={<VerifyEmailPage />} />
        <Route path="/reset-password" element={<ResetPasswordPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>

      {/* Customer area  ->  /api/user/** */}
      <Route element={<RequireRole role="ROLE_CUSTOMER" />}>
        <Route path="/account" element={<AppShell links={CUSTOMER_LINKS} />}>
          <Route index element={<Navigate to="profile" replace />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="security" element={<SecurityPage />} />
          <Route path="feedback" element={<FeedbackPage />} />
        </Route>
      </Route>

      {/* Admin area  ->  /api/admin/** */}
      <Route element={<RequireRole role="ROLE_ADMIN" />}>
        <Route path="/admin" element={<AppShell links={ADMIN_LINKS} />}>
          <Route index element={<Navigate to="users" replace />} />
          <Route path="users" element={<UsersPage />} />
          <Route path="feedback" element={<AdminFeedbackPage />} />
          <Route path="audit-log" element={<AuditLogPage />} />
        </Route>
      </Route>
    </Routes>
  )
}
