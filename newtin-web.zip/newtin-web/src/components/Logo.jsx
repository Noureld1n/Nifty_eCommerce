import { useId } from 'react'
import './Logo.css'

/**
 * Newtin mark: a black stick man running inside an apple.
 * Left half of the apple is light green, right half is light blue.
 *
 * speed: 'normal' | 'fast' | 'paused'
 * The limbs are two-segment groups (thigh + shin, arm + forearm) that rotate
 * around the hip, knee, shoulder and elbow, which is what reads as "running".
 */
export default function Logo({ size = 96, speed = 'normal', wordmark = false, className = '' }) {
  const clipId = `apple-clip-${useId().replace(/:/g, '')}`
  return (
    <span className={`logo ${wordmark ? 'logo--wordmark' : ''} ${className}`} data-speed={speed}>
      <svg
        className="logo__svg"
        width={size}
        height={size}
        viewBox="0 0 120 120"
        role="img"
        aria-label="Newtin"
      >
        <defs>
          <clipPath id={clipId}>
            <path d="M60 31 C48 22 21 27 20 57 C19 87 40 109 54 105 C58 104 62 104 66 105 C80 109 101 87 100 57 C99 27 72 22 60 31 Z" />
          </clipPath>
        </defs>

        {/* ground shadow */}
        <ellipse className="logo__shadow" cx="60" cy="113" rx="26" ry="3.2" />

        <g className="logo__apple">
          <g clipPath={`url(#${clipId})`}>
            <rect x="0" y="0" width="60" height="120" fill="#9BE3B8" />
            <rect x="60" y="0" width="60" height="120" fill="#9CD3F5" />
          </g>
          {/* stem + leaf */}
          <path d="M60 31 C60 23 62 17 68 12" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
          <path d="M66 17 C70 8 82 8 88 12 C84 20 74 22 66 17 Z" fill="#9BE3B8" />
        </g>

        {/* runner */}
        <g className="logo__runner">
          <g className="logo__body">
            {/* back arm and back leg are drawn first so the front limbs overlap them */}
            <g className="limb limb--arm limb--back" style={{ transformOrigin: '61px 62px' }}>
              <line x1="61" y1="62" x2="61" y2="70" />
              <g className="limb__lower" style={{ transformOrigin: '61px 70px' }}>
                <line x1="61" y1="70" x2="61" y2="78" />
              </g>
            </g>
            <g className="limb limb--leg limb--back" style={{ transformOrigin: '59px 77px' }}>
              <line x1="59" y1="77" x2="59" y2="89" />
              <g className="limb__lower" style={{ transformOrigin: '59px 89px' }}>
                <line x1="59" y1="89" x2="59" y2="100" />
              </g>
            </g>

            <g className="torso">
              <circle cx="63" cy="51" r="5.2" className="head" />
              <line x1="61" y1="57" x2="59" y2="77" />
            </g>

            <g className="limb limb--leg limb--front" style={{ transformOrigin: '59px 77px' }}>
              <line x1="59" y1="77" x2="59" y2="89" />
              <g className="limb__lower" style={{ transformOrigin: '59px 89px' }}>
                <line x1="59" y1="89" x2="59" y2="100" />
              </g>
            </g>
            <g className="limb limb--arm limb--front" style={{ transformOrigin: '61px 62px' }}>
              <line x1="61" y1="62" x2="61" y2="70" />
              <g className="limb__lower" style={{ transformOrigin: '61px 70px' }}>
                <line x1="61" y1="70" x2="61" y2="78" />
              </g>
            </g>
          </g>
        </g>
      </svg>
      {wordmark && <span className="logo__word">Newtin</span>}
    </span>
  )
}
