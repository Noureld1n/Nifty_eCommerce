import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { authApi } from '../../api/authApi'
import { homeFor, useAuth } from '../../auth/useAuth'
import AuthCard from '../../components/AuthCard'
import { Alert, Button, Field } from '../../components/ui'
import { useForm } from '../../hooks/useForm'
import { validate, validators } from '../../lib/validation'

export default function LoginPage() {
  const { login, notice, setNotice } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const { values, setErrors, bind } = useForm({ email: '', password: '' })
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [unverified, setUnverified] = useState(false)
  const [resendMsg, setResendMsg] = useState('')
  const flash = location.state?.message

  async function onSubmit(e) {
    e.preventDefault()
    setNotice('')
    setError('')
    setUnverified(false)
    setResendMsg('')

    const found = validate(values, {
      email: (v) => (v.trim().includes('@') ? '' : 'Enter the email you registered with'),
      password: validators.required('Password'),
    })
    setErrors(found)
    if (Object.keys(found).length) return

    setBusy(true)
    try {
      const user = await login(values.email.trim().toLowerCase(), values.password)
      const from = location.state?.from
      const sameArea = from && from.startsWith('/admin') === (user.role === 'ROLE_ADMIN') && from !== '/'
      navigate(sameArea ? from : homeFor(user), { replace: true })
    } catch (err) {
      setError(err.message)
      setUnverified(err.status === 403) // backend answers 403 only when the password was right but the email is unverified
    } finally {
      setBusy(false)
    }
  }

  async function resend() {
    try {
      const res = await authApi.resendVerification(values.email.trim())
      setResendMsg(res?.message || 'We sent a new verification email.')
    } catch (err) {
      setResendMsg(err.message)
    }
  }

  return (
    <AuthCard
      title="Welcome back"
      subtitle="Log in to keep your account and orders in one place."
      footer={<>New to Newtin? <Link to="/register">Create an account</Link></>}
    >
      {flash && <Alert tone="success">{flash}</Alert>}
      {notice && <Alert tone="info">{notice}</Alert>}
      {error && (
        <Alert
          tone="error"
          action={unverified && !resendMsg && <Button variant="ghost" small onClick={resend}>Resend verification email</Button>}
        >
          {error}
        </Alert>
      )}
      {resendMsg && <Alert tone="success">{resendMsg}</Alert>}

      <form className="form" onSubmit={onSubmit} noValidate>
        <Field label="Email" type="email" autoComplete="email" inputMode="email" autoFocus {...bind('email')} />
        <Field label="Password" type="password" autoComplete="current-password" {...bind('password')} />
        <div className="auth-card__links">
          <span />
          <Link to="/forgot-password">Forgot password?</Link>
        </div>
        <Button type="submit" full loading={busy}>Log in</Button>
      </form>
    </AuthCard>
  )
}
